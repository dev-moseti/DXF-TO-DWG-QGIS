import os
import shutil
import tempfile

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingContext,
    QgsProcessingException,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterNumber,
)

from .oda_converter import (
    OUTPUT_VERSIONS,
    DEFAULT_OUTPUT_VERSION_INDEX,
    find_oda_executable,
    run_oda_converter,
    compat_enum,
)


class BaseConvertFileAlgorithm(QgsProcessingAlgorithm):
    """Shared logic for single-file CAD conversion (DWG<->DXF).

    Subclasses set SOURCE_EXT / SOURCE_LABEL / DEST_EXT / DEST_LABEL /
    DEST_FILETYPE and the usual name()/displayName()/shortHelpString()
    metadata. Everything else — parameters, running ODA File Converter,
    validating the result, optionally loading it into the project — is
    handled once here so both conversion directions get the same
    reliability guarantees.
    """

    INPUT = "INPUT"
    OUTPUT = "OUTPUT"
    ODA_PATH = "ODA_PATH"
    OUT_VERSION = "OUT_VERSION"
    AUDIT = "AUDIT"
    LOAD_TO_PROJECT = "LOAD_TO_PROJECT"
    TIMEOUT_MINUTES = "TIMEOUT_MINUTES"

    SOURCE_EXT = "dwg"
    SOURCE_LABEL = "DWG"
    DEST_EXT = "dxf"
    DEST_LABEL = "DXF"
    DEST_FILETYPE = "DXF"

    def group(self):
        return "DWG / DXF Conversion"

    def groupId(self):
        return "dwg2dxf"

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT,
                "Input {} file".format(self.SOURCE_LABEL),
                behavior=compat_enum(QgsProcessingParameterFile, "File"),
                extension=self.SOURCE_EXT,
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT,
                "Output {} file".format(self.DEST_LABEL),
                fileFilter="{0} files (*.{1})".format(
                    self.DEST_LABEL, self.DEST_EXT
                ),
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.OUT_VERSION,
                "Output {} version".format(self.DEST_LABEL),
                options=OUTPUT_VERSIONS,
                defaultValue=DEFAULT_OUTPUT_VERSION_INDEX,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.AUDIT, "Audit / fix errors during conversion", defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.LOAD_TO_PROJECT,
                "Add resulting {} to the current project".format(self.DEST_LABEL),
                defaultValue=(self.DEST_EXT == "dxf"),
            )
        )

        oda_path_param = QgsProcessingParameterFile(
            self.ODA_PATH,
            "ODA File Converter executable (leave blank to auto-detect)",
            behavior=compat_enum(QgsProcessingParameterFile, "File"),
            optional=True,
        )
        oda_path_param.setFlags(
            oda_path_param.flags()
            | compat_enum(QgsProcessingParameterFile, "FlagAdvanced")
        )
        self.addParameter(oda_path_param)

        timeout_param = QgsProcessingParameterNumber(
            self.TIMEOUT_MINUTES,
            "Timeout in minutes (0 = no limit)",
            type=compat_enum(QgsProcessingParameterNumber, "Integer"),
            defaultValue=20,
            minValue=0,
        )
        timeout_param.setFlags(
            timeout_param.flags()
            | compat_enum(QgsProcessingParameterNumber, "FlagAdvanced")
        )
        self.addParameter(timeout_param)

    def processAlgorithm(self, parameters, context, feedback):
        input_file = self.parameterAsFile(parameters, self.INPUT, context)
        output_file = self.parameterAsFileOutput(parameters, self.OUTPUT, context)
        oda_path = self.parameterAsFile(
            parameters, self.ODA_PATH, context
        ) or find_oda_executable()
        output_version = OUTPUT_VERSIONS[
            self.parameterAsEnum(parameters, self.OUT_VERSION, context)
        ]
        audit = self.parameterAsBoolean(parameters, self.AUDIT, context)
        load_to_project = self.parameterAsBoolean(
            parameters, self.LOAD_TO_PROJECT, context
        )
        timeout_minutes = self.parameterAsInt(
            parameters, self.TIMEOUT_MINUTES, context
        )
        timeout_seconds = timeout_minutes * 60 if timeout_minutes > 0 else None

        if not input_file or not os.path.isfile(input_file):
            raise QgsProcessingException(
                "Input {} file does not exist.".format(self.SOURCE_LABEL)
            )

        with tempfile.TemporaryDirectory(prefix="dwg2dxf_in_") as tmp_in, \
                tempfile.TemporaryDirectory(prefix="dwg2dxf_out_") as tmp_out:

            tmp_src = os.path.join(tmp_in, os.path.basename(input_file))
            shutil.copy2(input_file, tmp_src)

            run_oda_converter(
                oda_path=oda_path,
                input_folder=tmp_in,
                output_folder=tmp_out,
                output_version=output_version,
                recursive=False,
                audit=audit,
                input_filter="*.{}".format(self.SOURCE_EXT),
                feedback=feedback,
                output_filetype=self.DEST_FILETYPE,
                timeout_seconds=timeout_seconds,
            )

            base = os.path.splitext(os.path.basename(input_file))[0]
            produced = os.path.join(tmp_out, base + "." + self.DEST_EXT)

            if not os.path.isfile(produced):
                raise QgsProcessingException(
                    "Conversion finished but no {} was produced for '{}'. "
                    "The source file may be corrupt, encrypted, or in an "
                    "unsupported version.".format(self.DEST_LABEL, input_file)
                )
            if os.path.getsize(produced) == 0:
                raise QgsProcessingException(
                    "Conversion produced an empty (0 byte) {} file for "
                    "'{}'. Treating this as a failed conversion — check "
                    "the source file and the log above for ODA File "
                    "Converter errors.".format(self.DEST_LABEL, input_file)
                )

            out_dir = os.path.dirname(output_file)
            if out_dir:
                os.makedirs(out_dir, exist_ok=True)
            shutil.move(produced, output_file)

        feedback.pushInfo("Wrote {}".format(output_file))

        if load_to_project and self.DEST_EXT == "dxf":
            layer_name = os.path.splitext(os.path.basename(output_file))[0]
            context.addLayerToLoadOnCompletion(
                output_file,
                QgsProcessingContext.LayerDetails(
                    layer_name, context.project(), self.OUTPUT
                ),
            )
        elif load_to_project:
            feedback.pushInfo(
                "Note: {} files can't be loaded as a QGIS layer directly, "
                "so the result was not added to the project.".format(
                    self.DEST_LABEL
                )
            )

        return {self.OUTPUT: output_file}
