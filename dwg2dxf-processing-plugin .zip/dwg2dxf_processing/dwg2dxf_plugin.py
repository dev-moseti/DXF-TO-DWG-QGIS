from qgis.core import QgsApplication

from .provider import Dwg2DxfProvider


class Dwg2DxfPlugin:
    """Registers the DWG->DXF Processing provider with QGIS.

    This plugin is intentionally UI-less: it only exposes Processing
    algorithms, so it can be driven headlessly (qgis_process), from
    models, or from PyQGIS scripts.
    """

    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initGui(self):
        self.provider = Dwg2DxfProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
