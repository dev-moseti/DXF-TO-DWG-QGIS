from .base_file_algorithm import BaseConvertFileAlgorithm


class ConvertDwgFileAlgorithm(BaseConvertFileAlgorithm):
    """Convert a single DWG file to DXF.

    Because this takes one file in and produces one file out, QGIS
    automatically offers "Run as Batch Process" for it, it can be chained
    in Processing models, called via processing.run() from a script, or
    invoked directly from the command line with qgis_process — no custom
    UI needed.
    """

    SOURCE_EXT = "dwg"
    SOURCE_LABEL = "DWG"
    DEST_EXT = "dxf"
    DEST_LABEL = "DXF"
    DEST_FILETYPE = "DXF"

    def createInstance(self):
        return ConvertDwgFileAlgorithm()

    def name(self):
        return "convert_dwg_file"

    def displayName(self):
        return "Convert DWG file to DXF"

    def shortHelpString(self):
        return (
            "Converts a single AutoCAD DWG file to DXF using the ODA File "
            "Converter. Requires ODA File Converter to be installed "
            "separately (free, opendesign.com). On headless Linux, "
            "xvfb-run must also be installed.\n\n"
            "Because this algorithm has one file in and one file out, it "
            "can be run in batch over many files via QGIS's built-in "
            "'Run as Batch Process', chained in a Processing model, or "
            "called from qgis_process / processing.run() in a script. "
            "For converting an entire folder in one go, use 'Bulk "
            "convert DWG folder to DXF' instead."
        )
