"""
Helpers for locating and invoking the ODA File Converter command-line/batch
mode to convert DWG files to DXF.

ODA File Converter is a free (but proprietary) tool from the Open Design
Alliance. It is NOT bundled with this plugin and must be installed
separately:

    https://www.opendesign.com/guestfiles/oda_file_converter

Command-line syntax (same on Windows/macOS/Linux):

    ODAFileConverter <input_folder> <output_folder> <out_version> \
        <out_type> <recurse 0|1> <audit 0|1> [input_filter] [output_filter]

Note: even in "batch" usage, ODA File Converter is a Qt GUI application
under the hood and requires a display. On headless Linux (servers, CI,
Docker) it must be run under a virtual framebuffer such as xvfb-run.
"""

import fnmatch
import glob
import os
import platform
import shutil
import time

from qgis.core import QgsProcessingException
from qgis.PyQt.QtCore import QProcess

# Output DXF/DWG versions supported by ODA File Converter's <out_version> arg.
OUTPUT_VERSIONS = [
    "ACAD9",
    "ACAD10",
    "ACAD12",
    "ACAD13",
    "ACAD14",
    "ACAD2000",
    "ACAD2004",
    "ACAD2007",
    "ACAD2010",
    "ACAD2013",
    "ACAD2018",
]
DEFAULT_OUTPUT_VERSION_INDEX = OUTPUT_VERSIONS.index("ACAD2018")


def compat_enum(container, name):
    """Resolve an enum member across PyQt5/PyQt6 (QGIS3/QGIS4) API styles.

    Older bindings (PyQt5, used by QGIS3) expose enum members as flat
    attributes, e.g. QProcess.NormalExit. Newer bindings (PyQt6, used by
    QGIS4) require going through the enum's own class, e.g.
    QProcess.ExitStatus.NormalExit. This searches both without needing to
    know the nested enum class's name in advance.
    """
    if hasattr(container, name):
        return getattr(container, name)
    for attr_name in dir(container):
        if attr_name.startswith("_"):
            continue
        attr = getattr(container, attr_name)
        if hasattr(attr, name):
            return getattr(attr, name)
    raise AttributeError(
        "Could not resolve enum member '{}' on {}".format(name, container)
    )


def _matches_filter(filename, filter_str):
    """Match a filename against a (possibly ';'-separated) glob filter.

    ODA File Converter accepts filters like '*.dwg' or '*.dwg;*.dws'.
    Matching is done case-insensitively for cross-platform consistency.
    """
    patterns = [p.strip() for p in (filter_str or "").split(";") if p.strip()]
    if not patterns:
        return True
    name_lower = filename.lower()
    return any(fnmatch.fnmatch(name_lower, p.lower()) for p in patterns)


def list_source_files(input_folder, input_filter, recursive):
    """List files under input_folder matching input_filter.

    Returns paths relative to input_folder (using OS-native separators),
    sorted for deterministic output. Used both to fail fast on an empty/
    wrong input folder, and to drive incremental (skip-already-converted)
    conversion.
    """
    matches = []
    if recursive:
        for root, _dirs, filenames in sorted(os.walk(input_folder)):
            for fn in sorted(filenames):
                if _matches_filter(fn, input_filter):
                    matches.append(
                        os.path.relpath(os.path.join(root, fn), input_folder)
                    )
    else:
        for fn in sorted(os.listdir(input_folder)):
            full = os.path.join(input_folder, fn)
            if os.path.isfile(full) and _matches_filter(fn, input_filter):
                matches.append(fn)
    return matches


def find_oda_executable():
    """Best-effort search for the ODAFileConverter executable.

    Returns the path if found, otherwise None. Users can always override
    this via the algorithm's "ODA File Converter executable" parameter.
    """
    system = platform.system()
    candidates = []

    if system == "Windows":
        exe_name = "ODAFileConverter.exe"
        program_dirs = [
            os.environ.get("PROGRAMFILES", r"C:\Program Files"),
            os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
        ]
        # Folder naming/nesting varies by installer version (e.g.
        # "ODA\ODAFileConverter 27.1.0\ODAFileConverter.exe" rather than a
        # single "ODA File Converter" folder directly under Program Files),
        # so search recursively instead of assuming a fixed layout.
        for pf in program_dirs:
            if pf and os.path.isdir(pf):
                candidates += glob.glob(
                    os.path.join(pf, "**", exe_name), recursive=True
                )
        which_hit = shutil.which(exe_name)
        if which_hit:
            candidates.append(which_hit)

    elif system == "Darwin":
        exe_name = "ODAFileConverter"
        candidates += glob.glob(
            "/Applications/ODAFileConverter*.app/Contents/MacOS/ODAFileConverter"
        )
        which_hit = shutil.which(exe_name)
        if which_hit:
            candidates.append(which_hit)

    else:  # Linux and other *nix
        exe_name = "ODAFileConverter"
        which_hit = shutil.which(exe_name)
        if which_hit:
            candidates.append(which_hit)
        candidates += [
            "/usr/bin/ODAFileConverter",
            "/usr/local/bin/ODAFileConverter",
        ]
        candidates += glob.glob("/opt/ODA*/ODAFileConverter")

    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return candidate

    return None


def run_oda_converter(
    oda_path,
    input_folder,
    output_folder,
    output_version,
    recursive,
    audit,
    input_filter,
    feedback,
    output_filetype="DXF",
    timeout_seconds=None,
):
    """Run ODA File Converter on a folder of files, blocking until done.

    Raises QgsProcessingException on any failure. Streams stdout/stderr to
    the Processing feedback log, respects cancellation, and (if
    timeout_seconds is set) kills the process and raises a clear error if
    it hasn't finished in time — protects against ODA File Converter
    hanging on an unexpected blocking dialog (e.g. a first-run prompt).
    """
    if not oda_path or not os.path.isfile(oda_path):
        raise QgsProcessingException(
            "ODA File Converter executable was not found. Install it from "
            "https://www.opendesign.com/guestfiles/oda_file_converter and "
            "either put it on your PATH or set the 'ODA File Converter "
            "executable' parameter to its full path."
        )

    os.makedirs(output_folder, exist_ok=True)

    oda_args = [
        input_folder,
        output_folder,
        output_version,
        output_filetype,
        "1" if recursive else "0",
        "1" if audit else "0",
        input_filter or "*.DWG",
    ]

    program = oda_path
    args = oda_args

    if platform.system() == "Linux" and not os.environ.get("DISPLAY"):
        # ODA File Converter is a GUI app under the hood and needs a
        # display even for "headless" batch conversion. Wrap with
        # xvfb-run so this works on servers / in automated pipelines.
        xvfb = shutil.which("xvfb-run")
        if not xvfb:
            raise QgsProcessingException(
                "No DISPLAY is set and 'xvfb-run' was not found. ODA File "
                "Converter requires a display even in batch mode on Linux. "
                "Install xvfb (e.g. 'sudo apt install xvfb') so this "
                "algorithm can run headlessly, or run QGIS with a display "
                "available."
            )
        program = xvfb
        args = ["-a", oda_path] + oda_args

    feedback.pushInfo("Running: {} {}".format(program, " ".join(args)))

    process = QProcess()
    process.setProgram(program)
    process.setArguments(args)
    process.start()

    if not process.waitForStarted(10000):
        raise QgsProcessingException(
            "Failed to start ODA File Converter at '{}'.".format(program)
        )

    start_time = time.monotonic()
    while not process.waitForFinished(500):
        if feedback.isCanceled():
            process.kill()
            raise QgsProcessingException("Conversion canceled by user.")
        if timeout_seconds and (time.monotonic() - start_time) > timeout_seconds:
            process.kill()
            raise QgsProcessingException(
                "ODA File Converter did not finish within {} minute(s) and "
                "was terminated. It may be stuck on a blocking dialog (e.g. "
                "a first-run or overwrite prompt) — try running ODA File "
                "Converter manually once first to clear any such prompts, "
                "or increase the timeout.".format(int(timeout_seconds // 60))
            )
        _flush_process_output(process, feedback)

    _flush_process_output(process, feedback)

    normal_exit = compat_enum(QProcess, "NormalExit")

    if process.exitStatus() != normal_exit or process.exitCode() != 0:
        raise QgsProcessingException(
            "ODA File Converter exited with code {}. See log above for "
            "details.".format(process.exitCode())
        )

    return output_folder


def _flush_process_output(process, feedback):
    out = bytes(process.readAllStandardOutput()).decode(errors="replace").strip()
    err = bytes(process.readAllStandardError()).decode(errors="replace").strip()
    if out:
        feedback.pushInfo(out)
    if err:
        feedback.pushInfo(err)
