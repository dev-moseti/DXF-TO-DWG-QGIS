from .base_folder_algorithm import BaseConvertFolderAlgorithm


class ConvertDxfToDwgFolderAlgorithm(BaseConvertFolderAlgorithm):
    """Bulk-convert every DXF file in a folder to AutoCAD DWG."""

    SOURCE_EXT = "dxf"
    SOURCE_LABEL = "DXF"
    DEST_EXT = "dwg"
    DEST_LABEL = "DWG"
    DEST_FILETYPE = "DWG"
    DEFAULT_FILTER = "*.DXF"

    def createInstance(self):
        return ConvertDxfToDwgFolderAlgorithm()

    def name(self):
        return "convert_dxf_to_dwg_folder"

    def displayName(self):
        return "Bulk convert DXF folder to DWG"

    def shortHelpString(self):
        return (
            "Bulk-converts every DXF file in a folder to AutoCAD DWG — "
            "the reverse direction, useful for sending QGIS work back "
            "into AutoCAD workflows. Files already converted (and "
            "unchanged since) are skipped by default, so it's safe to "
            "re-run over the same folder repeatedly. Requires ODA File "
            "Converter to be installed separately (free, "
            "opendesign.com). On headless Linux, xvfb-run must also be "
            "installed."
        )
