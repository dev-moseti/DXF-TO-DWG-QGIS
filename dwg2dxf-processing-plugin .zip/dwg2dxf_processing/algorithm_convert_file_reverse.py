from .base_file_algorithm import BaseConvertFileAlgorithm


class ConvertDxfToDwgFileAlgorithm(BaseConvertFileAlgorithm):
    """Convert a single DXF file to AutoCAD DWG (the reverse direction)."""

    SOURCE_EXT = "dxf"
    SOURCE_LABEL = "DXF"
    DEST_EXT = "dwg"
    DEST_LABEL = "DWG"
    DEST_FILETYPE = "DWG"

    def createInstance(self):
        return ConvertDxfToDwgFileAlgorithm()

    def name(self):
        return "convert_dxf_to_dwg_file"

    def displayName(self):
        return "Convert DXF file to DWG"

    def shortHelpString(self):
        return (
            "Converts a single DXF file to AutoCAD DWG using the ODA "
            "File Converter — the reverse direction, useful for handing "
            "QGIS-exported or QGIS-edited DXF work back to AutoCAD "
            "users. Requires ODA File Converter to be installed "
            "separately (free, opendesign.com). On headless Linux, "
            "xvfb-run must also be installed.\n\n"
            "DWG files can't be loaded as a QGIS layer, so unlike the "
            "DWG-to-DXF algorithms this one does not add its result to "
            "the project."
        )
