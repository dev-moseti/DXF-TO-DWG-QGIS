# DWG / DXF Converter (QGIS Processing plugin)

Bidirectional, incremental conversion between AutoCAD DWG and DXF, built as
four QGIS Processing algorithms that wrap the free **ODA File Converter**
command-line tool. No custom dialog — run from `qgis_process`, chain into a
Processing model, or call with `processing.run()` from any script.

Developed by **Kelvin Moseti** — https://www.linkedin.com/in/kelvin-moseti-welkinsgroup

## 1. Install ODA File Converter (required, separate download)

This plugin does **not** bundle a DWG reader/writer — no free/open tool can
legally redistribute Autodesk's format libraries. It drives ODA's official,
free converter instead:

- Download: https://www.opendesign.com/guestfiles/oda_file_converter
- Windows, macOS, and Linux builds available.
- **Linux headless/servers/CI**: ODA File Converter is a Qt GUI app under
  the hood, so it needs a display even in batch mode. Install `xvfb`:
  `sudo apt install xvfb`. The plugin auto-wraps calls with `xvfb-run`
  when no `$DISPLAY` is set.

The plugin tries to auto-detect the installed executable by searching
recursively under `Program Files` (Windows), `/Applications` (macOS), and
common Linux install paths / `$PATH`. If it can't find it, set the path
explicitly via the algorithm's **"ODA File Converter executable"**
(advanced) parameter.

## 2. Install the plugin

1. Zip this folder (`dwg2dxf_processing/`) — or use the pre-built zip.
2. QGIS → Plugins → Manage and Install Plugins → Install from ZIP.
3. Once enabled, four algorithms appear under **Processing Toolbox → DWG /
   DXF Conversion**:
   - **Convert DWG file to DXF** — single file in, single file out.
   - **Bulk convert DWG folder to DXF** — converts a whole folder.
   - **Convert DXF file to DWG** — reverse direction, single file.
   - **Bulk convert DXF folder to DWG** — reverse direction, whole folder.

## 3. Reliability features (all four algorithms)

- **Timeout protection** — if ODA File Converter hangs (e.g. stuck on a
  first-run or overwrite prompt), the process is killed after a
  configurable number of minutes (advanced parameter, default 20/30) and a
  clear error is raised, instead of the algorithm hanging forever.
- **Corrupt/empty-output detection** — a 0-byte result is treated as a
  failed conversion, not a silent success.
- **Pre-flight validation** (bulk algorithms) — checks the input folder
  actually contains files matching the filter *before* invoking ODA, and
  fails immediately with a clear message if not (wrong folder, empty
  folder, wrong filter, etc.).
- **Per-file failure reporting** (bulk algorithms) — if some files fail to
  convert, the log names exactly which ones, rather than just a count.

## 4. Incremental / "skip already converted" mode (bulk algorithms)

Bulk conversions default to **skipping files that are already converted
and unchanged** (same name, output newer than input, non-empty). This
means:

- Re-running the same folder repeatedly is fast and safe — only new or
  modified files get (re)converted.
- Good for pipelines that run on a schedule against a folder that
  accumulates new DWG/DXF files over time.

Turn this off via the **"Skip files already converted"** parameter if you
always want a full, from-scratch conversion.

## 5. Load results into the current project

DXF results (from either DWG→DXF algorithm) can be added to the current
QGIS project automatically — on by default, toggle via **"Add resulting
DXF to the current project"**. This only applies to DXF outputs: DWG files
can't be read as a QGIS layer, so the two DXF→DWG algorithms don't offer
this option.

## 6. Automated / headless usage

### Command line (`qgis_process`)

```bash
# Single file, DWG -> DXF
qgis_process run dwg2dxf:convert_dwg_file \
  --INPUT=/data/plan.dwg \
  --OUTPUT=/data/plan.dxf

# Whole folder, DWG -> DXF, recursive, incremental by default
qgis_process run dwg2dxf:convert_dwg_folder \
  --INPUT=/data/incoming_dwgs \
  --OUTPUT=/data/converted_dxfs \
  --RECURSIVE=true

# Reverse direction, whole folder, DXF -> DWG
qgis_process run dwg2dxf:convert_dxf_to_dwg_folder \
  --INPUT=/data/dxfs_to_send_back \
  --OUTPUT=/data/dwgs_for_autocad
```

### From a PyQGIS script / another plugin

```python
import processing

result = processing.run("dwg2dxf:convert_dwg_folder", {
    "INPUT": "/data/incoming_dwgs",
    "OUTPUT": "/data/converted_dxfs",
    "RECURSIVE": True,
    "SKIP_EXISTING": True,
    "TIMEOUT_MINUTES": 30,
})
print(result["OUTPUT"])
```

### Batch mode over many individual files

Because the single-file algorithms take exactly one file in and one out,
QGIS's built-in **"Run as Batch Process"** button (right-click the
algorithm in the Processing Toolbox) works automatically.

## Parameters reference

| Parameter | Applies to | Notes |
|---|---|---|
| `INPUT` | both | File (single) or folder (bulk) |
| `OUTPUT` | both | Destination file or folder |
| `OUT_VERSION` | both | Enum index into `OUTPUT_VERSIONS` in `oda_converter.py`; default `ACAD2018` |
| `RECURSIVE` | folder only | Recurse into subfolders |
| `AUDIT` | both | Ask ODA to audit/fix errors during conversion |
| `SKIP_EXISTING` | folder only | Incremental mode; default on |
| `LOAD_TO_PROJECT` | both | Only takes effect for DXF outputs |
| `INPUT_FILTER` | folder only | Filename glob (supports `;`-separated patterns), default `*.DWG` / `*.DXF` |
| `TIMEOUT_MINUTES` | both | Advanced, optional. `0` disables the timeout |
| `ODA_PATH` | both | Advanced, optional. Overrides auto-detection |

## Known limitations

- Conversion quality/fidelity is entirely dependent on ODA File
  Converter — this plugin just automates calling it, validating results,
  and wiring them into QGIS.
- Encrypted DWGs will fail the conversion; the algorithm raises a clear
  `QgsProcessingException` in that case.
- No fine-grained progress bar: ODA's CLI doesn't report per-file
  progress, so the log shows raw stdout/stderr plus summary counts
  instead.
