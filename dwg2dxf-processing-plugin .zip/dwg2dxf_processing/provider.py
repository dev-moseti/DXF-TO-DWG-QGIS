from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon

from .algorithm_convert_file import ConvertDwgFileAlgorithm
from .algorithm_convert_folder import ConvertDwgFolderAlgorithm
from .algorithm_convert_file_reverse import ConvertDxfToDwgFileAlgorithm
from .algorithm_convert_folder_reverse import ConvertDxfToDwgFolderAlgorithm


class Dwg2DxfProvider(QgsProcessingProvider):

    def id(self):
        return "dwg2dxf"

    def name(self):
        return "DWG / DXF Conversion"

    def longName(self):
        return "DWG / DXF Conversion (via ODA File Converter)"

    def icon(self):
        return QIcon()

    def loadAlgorithms(self):
        self.addAlgorithm(ConvertDwgFileAlgorithm())
        self.addAlgorithm(ConvertDwgFolderAlgorithm())
        self.addAlgorithm(ConvertDxfToDwgFileAlgorithm())
        self.addAlgorithm(ConvertDxfToDwgFolderAlgorithm())
