import os
import shutil
import tempfile

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingContext,
    QgsProcessingException,
    QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
)

from .oda_converter import (
    OUTPUT_VERSIONS,
    DEFAULT_OUTPUT_VERSION_INDEX,
    find_oda_executable,
    run_oda_converter,
    list_source_files,
    compat_enum,
)


class BaseConvertFolderAlgorithm(QgsProcessingAlgorithm):
    """Shared logic for bulk/folder CAD conversion (DWG<->DXF).

    Subclasses set SOURCE_EXT / SOURCE_LABEL / DEST_EXT / DEST_LABEL /
    DEST_FILETYPE / DEFAULT_FILTER and the usual name()/displayName()/
    shortHelpString() metadata.

    Reliability features shared by both directions:
    - Fails fast with a clear error if no matching source files exist,
      instead of silently doing nothing.
    - Skips files that are already converted and unchanged by default
      ("incremental" mode), so re-running over the same folder is safe
      and fast — useful for repeated pipeline runs.
    - Reports exactly which files failed to convert, rather than just a
      count.
    """

    INPUT = "INPUT"
    OUTPUT = "OUTPUT"
    ODA_PATH = "ODA_PATH"
    OUT_VERSION = "OUT_VERSION"
    RECURSIVE = "RECURSIVE"
    AUDIT = "AUDIT"
    INPUT_FILTER = "INPUT_FILTER"
    LOAD_TO_PROJECT = "LOAD_TO_PROJECT"
    SKIP_EXISTING = "SKIP_EXISTING"
    TIMEOUT_MINUTES = "TIMEOUT_MINUTES"

    SOURCE_EXT = "dwg"
    SOURCE_LABEL = "DWG"
    DEST_EXT = "dxf"
    DEST_LABEL = "DXF"
    DEST_FILETYPE = "DXF"
    DEFAULT_FILTER = "*.DWG"

    def group(self):
        return "DWG / DXF Conversion"

    def groupId(self):
        return "dwg2dxf"

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT,
                "Input folder containing {} files".format(self.SOURCE_LABEL),
                behavior=compat_enum(QgsProcessingParameterFile, "Folder"),
            )
        )
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT, "Output folder for {} files".format(self.DEST_LABEL)
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.OUT_VERSION,
                "Output {} version".format(self.DEST_LABEL),
                options=OUTPUT_VERSIONS,
                defaultValue=DEFAULT_OUTPUT_VERSION_INDEX,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.RECURSIVE, "Recurse into subfolders", defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.AUDIT, "Audit / fix errors during conversion", defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SKIP_EXISTING,
                "Skip files already converted (only convert new/changed files)",
                defaultValue=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.LOAD_TO_PROJECT,
                "Add resulting {} file(s) to the current project".format(
                    self.DEST_LABEL
                ),
                defaultValue=(self.DEST_EXT == "dxf"),
            )
        )

        input_filter_param = QgsProcessingParameterString(
            self.INPUT_FILTER, "Input filename filter", defaultValue=self.DEFAULT_FILTER
        )
        input_filter_param.setFlags(
            input_filter_param.flags()
            | compat_enum(QgsProcessingParameterString, "FlagAdvanced")
        )
        self.addParameter(input_filter_param)

        oda_path_param = QgsProcessingParameterFile(
            self.ODA_PATH,
            "ODA File Converter executable (leave blank to auto-detect)",
            behavior=compat_enum(QgsProcessingParameterFile, "File"),
            optional=True,
        )
        oda_path_param.setFlags(
            oda_path_param.flags()
            | compat_enum(QgsProcessingParameterFile, "FlagAdvanced")
        )
        self.addParameter(oda_path_param)

        timeout_param = QgsProcessingParameterNumber(
            self.TIMEOUT_MINUTES,
            "Timeout in minutes (0 = no limit)",
            type=compat_enum(QgsProcessingParameterNumber, "Integer"),
            defaultValue=30,
            minValue=0,
        )
        timeout_param.setFlags(
            timeout_param.flags()
            | compat_enum(QgsProcessingParameterNumber, "FlagAdvanced")
        )
        self.addParameter(timeout_param)

    def processAlgorithm(self, parameters, context, feedback):
        input_folder = self.parameterAsFile(parameters, self.INPUT, context)
        output_folder = self.parameterAsString(parameters, self.OUTPUT, context)
        oda_path = self.parameterAsFile(
            parameters, self.ODA_PATH, context
        ) or find_oda_executable()
        output_version = OUTPUT_VERSIONS[
            self.parameterAsEnum(parameters, self.OUT_VERSION, context)
        ]
        recursive = self.parameterAsBoolean(parameters, self.RECURSIVE, context)
        audit = self.parameterAsBoolean(parameters, self.AUDIT, context)
        input_filter = self.parameterAsString(parameters, self.INPUT_FILTER, context)
        load_to_project = self.parameterAsBoolean(
            parameters, self.LOAD_TO_PROJECT, context
        )
        skip_existing = self.parameterAsBoolean(
            parameters, self.SKIP_EXISTING, context
        )
        timeout_minutes = self.parameterAsInt(
            parameters, self.TIMEOUT_MINUTES, context
        )
        timeout_seconds = timeout_minutes * 60 if timeout_minutes > 0 else None

        if not input_folder or not os.path.isdir(input_folder):
            raise QgsProcessingException(
                "Input must be an existing folder containing {} "
                "files.".format(self.SOURCE_LABEL)
            )

        os.makedirs(output_folder, exist_ok=True)

        all_sources = list_source_files(input_folder, input_filter, recursive)
        if not all_sources:
            raise QgsProcessingException(
                "No files matching '{}' were found in {}. Check the "
                "folder and filename filter.".format(input_filter, input_folder)
            )

        def dest_rel_for(rel):
            return os.path.splitext(rel)[0] + "." + self.DEST_EXT

        if skip_existing:
            pending = []
            for rel in all_sources:
                dest_full = os.path.join(output_folder, dest_rel_for(rel))
                src_full = os.path.join(input_folder, rel)
                already_done = (
                    os.path.isfile(dest_full)
                    and os.path.getsize(dest_full) > 0
                    and os.path.getmtime(dest_full) >= os.path.getmtime(src_full)
                )
                if not already_done:
                    pending.append(rel)
        else:
            pending = list(all_sources)

        failed = []

        if not pending:
            feedback.pushInfo(
                "All {} matching file(s) are already converted and up to "
                "date; nothing to do.".format(len(all_sources))
            )
        else:
            feedback.pushInfo(
                "Converting {} of {} matching file(s) ({} already up to "
                "date)".format(
                    len(pending), len(all_sources), len(all_sources) - len(pending)
                )
            )

            if len(pending) == len(all_sources):
                run_oda_converter(
                    oda_path=oda_path,
                    input_folder=input_folder,
                    output_folder=output_folder,
                    output_version=output_version,
                    recursive=recursive,
                    audit=audit,
                    input_filter=input_filter,
                    feedback=feedback,
                    output_filetype=self.DEST_FILETYPE,
                    timeout_seconds=timeout_seconds,
                )
            else:
                # Only some files need (re)conversion: mirror just those
                # into a temp folder, preserving relative structure, so
                # ODA File Converter doesn't needlessly reprocess files
                # that are already up to date.
                with tempfile.TemporaryDirectory(prefix="dwg2dxf_pending_") as tmp_in:
                    for rel in pending:
                        src = os.path.join(input_folder, rel)
                        dst = os.path.join(tmp_in, rel)
                        dst_dir = os.path.dirname(dst)
                        if dst_dir:
                            os.makedirs(dst_dir, exist_ok=True)
                        shutil.copy2(src, dst)
                    run_oda_converter(
                        oda_path=oda_path,
                        input_folder=tmp_in,
                        output_folder=output_folder,
                        output_version=output_version,
                        recursive=True,
                        audit=audit,
                        input_filter=input_filter,
                        feedback=feedback,
                        output_filetype=self.DEST_FILETYPE,
                        timeout_seconds=timeout_seconds,
                    )

            for rel in pending:
                dest_full = os.path.join(output_folder, dest_rel_for(rel))
                if not (os.path.isfile(dest_full) and os.path.getsize(dest_full) > 0):
                    failed.append(rel)

            if failed:
                feedback.reportError(
                    "{} file(s) failed to convert: {}".format(
                        len(failed), ", ".join(failed)
                    )
                )

        converted_paths = []
        for rel in all_sources:
            if rel in failed:
                continue
            dest_full = os.path.join(output_folder, dest_rel_for(rel))
            if os.path.isfile(dest_full):
                converted_paths.append(dest_full)

        feedback.pushInfo(
            "{} {} file(s) available in {}{}".format(
                len(converted_paths),
                self.DEST_LABEL,
                output_folder,
                " ({} failed)".format(len(failed)) if failed else "",
            )
        )

        if load_to_project and self.DEST_EXT == "dxf":
            for dxf_path in converted_paths:
                layer_name = os.path.splitext(os.path.basename(dxf_path))[0]
                context.addLayerToLoadOnCompletion(
                    dxf_path,
                    QgsProcessingContext.LayerDetails(
                        layer_name, context.project(), self.OUTPUT
                    ),
                )
        elif load_to_project:
            feedback.pushInfo(
                "Note: {} files can't be loaded as a QGIS layer directly, "
                "so results were not added to the project.".format(
                    self.DEST_LABEL
                )
            )

        return {self.OUTPUT: output_folder}
