def classFactory(iface):
    """Load Dwg2DxfPlugin class from file dwg2dxf_plugin.py.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .dwg2dxf_plugin import Dwg2DxfPlugin
    return Dwg2DxfPlugin(iface)
