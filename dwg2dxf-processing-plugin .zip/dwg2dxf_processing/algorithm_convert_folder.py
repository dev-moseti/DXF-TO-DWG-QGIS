from .base_folder_algorithm import BaseConvertFolderAlgorithm


class ConvertDwgFolderAlgorithm(BaseConvertFolderAlgorithm):
    """Bulk-convert every DWG file in a folder to DXF."""

    SOURCE_EXT = "dwg"
    SOURCE_LABEL = "DWG"
    DEST_EXT = "dxf"
    DEST_LABEL = "DXF"
    DEST_FILETYPE = "DXF"
    DEFAULT_FILTER = "*.DWG"

    def createInstance(self):
        return ConvertDwgFolderAlgorithm()

    def name(self):
        return "convert_dwg_folder"

    def displayName(self):
        return "Bulk convert DWG folder to DXF"

    def shortHelpString(self):
        return (
            "Bulk-converts every DWG file in a folder to DXF using a "
            "single ODA File Converter invocation — the option to use "
            "when you have many files at once rather than converting "
            "one at a time. Files that were already converted (and are "
            "unchanged since) are skipped by default, so it's safe to "
            "re-run over the same folder repeatedly. Requires ODA File "
            "Converter to be installed separately (free, opendesign.com). "
            "On headless Linux, xvfb-run must also be installed.\n\n"
            "Call this from qgis_process or processing.run() for fully "
            "automated/headless pipelines, or run it interactively from "
            "the Processing Toolbox."
        )
